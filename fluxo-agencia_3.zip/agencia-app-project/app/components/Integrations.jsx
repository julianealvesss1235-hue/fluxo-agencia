"use client";
import React, { useState } from "react";
import { Calendar, CheckCircle2, RefreshCw, ExternalLink, Trello as TrelloIcon, AlertCircle, ChevronRight } from "lucide-react";
import { CATEGORIES, STATUS } from "../lib/constants";
import { fetchBoards, fetchLists, fetchCardsWithChecklists, guessStatusFromListName, guessCategoryFromListName, trelloCardToTask } from "../lib/trello";

const inputStyle = {
  width: "100%", padding: "9px 12px", borderRadius: 10, border: "1px solid var(--border)",
  background: "var(--bg)", color: "var(--text)", fontSize: 14, fontFamily: "inherit", outline: "none", boxSizing: "border-box",
};

function Section({ icon: Icon, title, subtitle, children }) {
  return (
    <div className="card" style={{ padding: 22, marginBottom: 18 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
        <div style={{ width: 32, height: 32, borderRadius: 9, background: "var(--accent-soft)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon size={16} color="var(--accent)" />
        </div>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 600, margin: 0 }}>{title}</h2>
      </div>
      {subtitle && <p style={{ color: "var(--muted)", fontSize: 13, margin: "0 0 16px", marginLeft: 42 }}>{subtitle}</p>}
      <div style={{ marginLeft: 0 }}>{children}</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 14 }}>
      <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--muted)" }}>{label}</span>
      {children}
    </label>
  );
}

export default function Integrations({
  clients, googleAuth, googleEvents, googleSyncing, googleError,
  onConnectGoogle, onDisconnectGoogle, onSyncGoogle, onSetCalendarId,
  onImportTrello,
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0, maxWidth: 640 }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 24, fontWeight: 600, margin: "0 0 4px" }}>Integrações</h1>
        <p style={{ margin: 0, color: "var(--muted)", fontSize: 14 }}>Conecte suas outras ferramentas ao Fluxo.</p>
      </div>

      <GoogleSection
        googleAuth={googleAuth} googleEvents={googleEvents} googleSyncing={googleSyncing} googleError={googleError}
        onConnect={onConnectGoogle} onDisconnect={onDisconnectGoogle} onSync={onSyncGoogle} onSetCalendarId={onSetCalendarId}
      />
      <TrelloSection clients={clients} onImport={onImportTrello} />
    </div>
  );
}

/* ----------------------------- Google Calendar ----------------------------- */

function GoogleSection({ googleAuth, googleEvents, googleSyncing, googleError, onConnect, onDisconnect, onSync, onSetCalendarId }) {
  const [clientIdInput, setClientIdInput] = useState(googleAuth.clientId || "");
  const [showHelp, setShowHelp] = useState(false);
  const needsReconnect = googleAuth.connected && !googleAuth.accessToken;

  return (
    <Section icon={Calendar} title="Google Agenda" subtitle="Sincronia nos dois sentidos: prazos de tarefas viram eventos, e mudanças na agenda atualizam as tarefas.">
      {!googleAuth.connected && (
        <>
          <Field label="Client ID do Google (OAuth)">
            <input style={inputStyle} value={clientIdInput} onChange={(e) => setClientIdInput(e.target.value)} placeholder="xxxxxxxx.apps.googleusercontent.com" />
          </Field>
          <button className="btn-primary" disabled={!clientIdInput.trim()} onClick={() => onConnect(clientIdInput.trim())}>
            <Calendar size={14} /> Conectar Google Agenda
          </button>
          <button
            onClick={() => setShowHelp((s) => !s)}
            style={{ background: "none", border: "none", color: "var(--accent)", fontSize: 12.5, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, marginTop: 10, padding: 0 }}
          >
            <ChevronRight size={13} style={{ transform: showHelp ? "rotate(90deg)" : "none" }} />
            Onde eu pego o Client ID?
          </button>
          {showHelp && (
            <ol style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 10, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 6 }}>
              <li>Acesse <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noreferrer" style={{ color: "var(--accent)" }}>console.cloud.google.com/apis/credentials <ExternalLink size={10} style={{ display: "inline" }} /></a> e crie um projeto (gratuito).</li>
              <li>Em "Tela de consentimento OAuth", configure como "Externo" e adicione seu e-mail como usuário de teste.</li>
              <li>Ative a <strong>Google Calendar API</strong> em "APIs e serviços → Biblioteca".</li>
              <li>Em "Credenciais → Criar credenciais → ID do cliente OAuth", tipo <strong>Aplicativo da Web</strong>.</li>
              <li>Em "Origens JavaScript autorizadas", adicione o link do seu app publicado na Vercel (ex: <code>https://fluxo-agencia.vercel.app</code>).</li>
              <li>Copie o <strong>Client ID</strong> gerado e cole aqui.</li>
            </ol>
          )}
        </>
      )}

      {googleAuth.connected && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <CheckCircle2 size={16} color="#1FA97A" />
            <span style={{ fontSize: 13.5, fontWeight: 500 }}>Conectado</span>
          </div>
          {needsReconnect && (
            <div style={{ fontSize: 12.5, color: "var(--muted)", background: "var(--hover)", padding: "8px 10px", borderRadius: 8 }}>
              Sua sessão expirou (isso é normal a cada nova visita). Clique em "Sincronizar" para reconectar.
            </div>
          )}
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btn-secondary" onClick={onSync} disabled={googleSyncing}>
              <RefreshCw size={13} style={{ marginRight: 6, ...(googleSyncing ? { animation: "spin 1s linear infinite" } : {}) }} />
              {googleSyncing ? "Sincronizando..." : "Sincronizar agora"}
            </button>
            <button className="btn-secondary" onClick={onDisconnect}>Desconectar</button>
          </div>
          {googleEvents.length > 0 && (
            <div style={{ fontSize: 12.5, color: "var(--muted)" }}>
              {googleEvents.length} evento(s) da sua agenda (fora do Fluxo) nos próximos dias.
            </div>
          )}
        </div>
      )}
      {googleError && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, color: "#FF6B5B", fontSize: 12.5 }}>
          <AlertCircle size={13} /> {googleError}
        </div>
      )}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </Section>
  );
}

/* ----------------------------- Trello ----------------------------- */

function TrelloSection({ clients, onImport }) {
  const [key, setKey] = useState("");
  const [token, setToken] = useState("");
  const [boards, setBoards] = useState(null);
  const [selectedBoard, setSelectedBoard] = useState(null);
  const [lists, setLists] = useState([]);
  const [listMap, setListMap] = useState({}); // listId -> { category, skip }
  const [cards, setCards] = useState([]);
  const [targetMode, setTargetMode] = useState("new"); // 'new' | existing client id
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [imported, setImported] = useState(null);
  const [showHelp, setShowHelp] = useState(false);

  const loadBoards = async () => {
    setError(""); setLoading(true);
    try {
      const data = await fetchBoards(key.trim(), token.trim());
      setBoards(data);
    } catch (e) {
      setError("Não consegui buscar seus quadros. Confira a chave e o token.");
    } finally {
      setLoading(false);
    }
  };

  const selectBoard = async (board) => {
    setError(""); setLoading(true);
    setSelectedBoard(board);
    try {
      const [l, c] = await Promise.all([
        fetchLists(board.id, key.trim(), token.trim()),
        fetchCardsWithChecklists(board.id, key.trim(), token.trim()),
      ]);
      setLists(l);
      setCards(c.filter((card) => !card.closed));
      const initialMap = {};
      l.forEach((list) => {
        initialMap[list.id] = { category: guessCategoryFromListName(list.name, CATEGORIES), skip: false };
      });
      setListMap(initialMap);
    } catch (e) {
      setError("Não consegui ler esse quadro.");
    } finally {
      setLoading(false);
    }
  };

  const runImport = () => {
    const newTasks = cards
      .filter((card) => !listMap[card.idList]?.skip)
      .map((card) => {
        const map = listMap[card.idList] || { category: "outras" };
        const status = guessStatusFromListName(lists.find((l) => l.id === card.idList)?.name || "");
        return trelloCardToTask(card, { clientId: null, category: map.category, status });
      });

    const payload = { newTasks };
    if (targetMode === "new") {
      payload.newClient = { create: { name: selectedBoard.name, area: "", contact: "", whatsapp: "", notes: "Importado do Trello", contractType: "Mensal recorrente", monthlyValue: "", startDate: new Date().toISOString().slice(0, 10) } };
    } else {
      payload.newClient = { existingId: targetMode };
    }
    const count = onImport(payload);
    setImported(count);
  };

  const reset = () => {
    setBoards(null); setSelectedBoard(null); setLists([]); setCards([]); setListMap({}); setImported(null);
  };

  return (
    <Section icon={TrelloIcon} title="Trello" subtitle="Importação única: traz quadro, listas e cards para dentro de um cliente do Fluxo.">
      {!boards && (
        <>
          <Field label="Chave da API (API Key)">
            <input style={inputStyle} value={key} onChange={(e) => setKey(e.target.value)} placeholder="Cole sua API key" />
          </Field>
          <Field label="Token">
            <input style={inputStyle} value={token} onChange={(e) => setToken(e.target.value)} placeholder="Cole seu token" />
          </Field>
          <button className="btn-primary" disabled={!key.trim() || !token.trim() || loading} onClick={loadBoards}>
            <TrelloIcon size={14} /> {loading ? "Buscando..." : "Buscar meus quadros"}
          </button>
          <button
            onClick={() => setShowHelp((s) => !s)}
            style={{ background: "none", border: "none", color: "var(--accent)", fontSize: 12.5, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, marginTop: 10, padding: 0 }}
          >
            <ChevronRight size={13} style={{ transform: showHelp ? "rotate(90deg)" : "none" }} />
            Onde eu pego a chave e o token?
          </button>
          {showHelp && (
            <ol style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 10, paddingLeft: 18, display: "flex", flexDirection: "column", gap: 6 }}>
              <li>Acesse <a href="https://trello.com/power-ups/admin" target="_blank" rel="noreferrer" style={{ color: "var(--accent)" }}>trello.com/power-ups/admin <ExternalLink size={10} style={{ display: "inline" }} /></a> e crie um Power-Up novo (gratuito, é só pra gerar a chave).</li>
              <li>Na aba "API key" do Power-Up, copie a <strong>Key</strong>.</li>
              <li>Na mesma página, clique no link "Token" — autorize e copie o token gerado.</li>
              <li>Cole os dois aqui. Eles ficam salvos só no seu navegador.</li>
            </ol>
          )}
        </>
      )}

      {boards && !selectedBoard && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {boards.map((b) => (
            <div key={b.id} className="card client-row" style={{ padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }} onClick={() => selectBoard(b)}>
              <span style={{ fontSize: 14, fontWeight: 500 }}>{b.name}</span>
              <ChevronRight size={15} color="var(--muted)" />
            </div>
          ))}
          {boards.length === 0 && <p style={{ color: "var(--muted)", fontSize: 13 }}>Nenhum quadro encontrado nessa conta.</p>}
        </div>
      )}

      {selectedBoard && !imported && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontSize: 13.5 }}>
            Quadro: <strong>{selectedBoard.name}</strong> · {cards.length} card(s) em {lists.length} lista(s)
          </div>

          <Field label="Importar para">
            <select style={inputStyle} value={targetMode} onChange={(e) => setTargetMode(e.target.value)}>
              <option value="new">Criar novo cliente ("{selectedBoard.name}")</option>
              {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>

          <div>
            <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--muted)" }}>Mapeamento de listas → categoria</span>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 8 }}>
              {lists.map((list) => {
                const count = cards.filter((c) => c.idList === list.id).length;
                const map = listMap[list.id] || { category: "outras", skip: false };
                return (
                  <div key={list.id} style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 13, minWidth: 120 }}>{list.name} <span style={{ color: "var(--muted)" }}>({count})</span></span>
                    <select
                      style={{ ...inputStyle, width: "auto", flex: "1 1 160px" }}
                      value={map.category}
                      disabled={map.skip}
                      onChange={(e) => setListMap((m) => ({ ...m, [list.id]: { ...m[list.id], category: e.target.value } }))}
                    >
                      {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
                    </select>
                    <label style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "var(--muted)" }}>
                      <input type="checkbox" checked={map.skip} onChange={(e) => setListMap((m) => ({ ...m, [list.id]: { ...m[list.id], skip: e.target.checked } }))} />
                      não importar
                    </label>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn-secondary" onClick={reset}>Cancelar</button>
            <button className="btn-primary" onClick={runImport}>Importar {cards.filter((c) => !listMap[c.idList]?.skip).length} tarefa(s)</button>
          </div>
        </div>
      )}

      {imported !== null && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, color: "#1FA97A" }}>
            <CheckCircle2 size={16} /> <span style={{ fontSize: 13.5, fontWeight: 500 }}>{imported} tarefa(s) importada(s) com sucesso.</span>
          </div>
          <button className="btn-secondary" style={{ alignSelf: "flex-start" }} onClick={reset}>Importar outro quadro</button>
        </div>
      )}

      {error && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, color: "#FF6B5B", fontSize: 12.5 }}>
          <AlertCircle size={13} /> {error}
        </div>
      )}
    </Section>
  );
}
